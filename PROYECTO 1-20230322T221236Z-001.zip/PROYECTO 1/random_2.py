from numpy import *#importa la libreria numpy
from matplotlib.pyplot import*

x=random.rand(100);
y=random.rand(100);

scatter(x,y);
show();
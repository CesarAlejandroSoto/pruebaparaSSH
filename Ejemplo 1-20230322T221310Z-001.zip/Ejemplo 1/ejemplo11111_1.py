
a=20;
if a>10;
    a=5
    if a==10;
    
